#import os
#os.system('cls')

#with open("morsekodok.txt", "r", encoding="utf-8") as fajl:
#    kod_lista = []
#    for sor in fajl:
#        sor = sor.strip()
#        betu_es_morse = sor.split()
#        if len(betu_es_morse) == 2:
#            kod_lista.append(betu_es_morse)

#bill = input("Írj be egy szöveget: ").lower()
#morse_kod = []

#for karakter in bill:
#    if karakter == " ":
#        morse_kod.append("/")
#    else:
#        megfelelo_kod = "?"
#        for betu_es_morse in kod_lista:
#            if betu_es_morse[0] == karakter:
#                megfelelo_kod = betu_es_morse[1]
#        morse_kod.append(megfelelo_kod)

#print("Morse kód:")
#for kod in morse_kod:
#    print(kod, end=" / ")

#bemenet = input("\nÍrj be egy morse kódot: ").strip()
#morse_jelek = bemenet.split(" / ")

#eredmeny = []

#for kod in morse_jelek:
#    if kod != "":
#        megfelelo_betu = "?"
#        for betu_es_morse in kod_lista:
#            if betu_es_morse[1] == kod:
#                megfelelo_betu = betu_es_morse[0]
#        eredmeny.append(megfelelo_betu)

#print("A szöveg eredménye:")
#for betu in eredmeny:
#


import os
os.system('cls')

with open("morsekodok.txt", "r", encoding="utf-8") as fajl:
    kod_lista = []
    for sor in fajl:
        sor = sor.strip()
        betu_es_morse = sor.split()
        if len(betu_es_morse) == 2:
            kod_lista.append(betu_es_morse)

bill = input("Írj be egy szöveget: ").lower()
morse_kod = []

for karakter in bill:
    if karakter == " ":
        morse_kod.append("/")
    else:
        megfelelo_kod = "?"
        for betu_es_morse in kod_lista:
            if betu_es_morse[0] == karakter:
                megfelelo_kod = betu_es_morse[1]
        morse_kod.append(megfelelo_kod)

# Fájlba írás kezdete
with open("kimenet.txt", "w", encoding="utf-8") as output_file:
    output_file.write("Morse kód:\n")
    for kod in morse_kod:
        output_file.write(kod + " / ")
    output_file.write("\n")  # Új sor

bemenet = input("\nÍrj be egy morse kódot: ").strip()
morse_jelek = bemenet.split(" / ")

eredmeny = []

for kod in morse_jelek:
    if kod != "":
        megfelelo_betu = "?"
        for betu_es_morse in kod_lista:
            if betu_es_morse[1] == kod:
                megfelelo_betu = betu_es_morse[0]
        eredmeny.append(megfelelo_betu)

# Fájlba írás folytatása
with open("kimenet.txt", "a", encoding="utf-8") as output_file:
    output_file.write("A szöveg eredménye:\n")
    for betu in eredmeny:
        output_file.write(betu)

# Eredeti print kiírások
print("Morse kód:")
for kod in morse_kod:
    print(kod, end=" / ")

print("\nA szöveg eredménye:")
for betu in eredmeny:
    print(betu, end="")

print("\nA kimenet rögzítve lett a kimenet.txt fájlba.")
