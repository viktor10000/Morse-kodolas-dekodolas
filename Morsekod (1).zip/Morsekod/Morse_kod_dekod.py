import os
os.system('cls')

with open("morsekodok.txt", "r", encoding="utf-8") as fajl:
    kod_lista = [sor.strip().split() for sor in fajl if len(sor.strip().split()) == 2]

bill = input("Írj be egy szöveget: ").lower()
morse_kod = []
for karakter in bill:
    if karakter == " ":
        morse_kod.append("/")
    else:
        megfelelo_kod = "?"
        for betu_es_morse in kod_lista:
            if betu_es_morse[0] == karakter:
                megfelelo_kod = betu_es_morse[1]
                break
        morse_kod.append(megfelelo_kod)

with open("kimenet.txt", "w", encoding="utf-8") as output_file:
    output_file.write(f"{bill}\n")
    output_file.write(f"Morse kód: {' / '.join(morse_kod)}\n")

morse = input("Írj be egy morse kódot: ").strip()
morse_jelek = morse.split(" / ")
eredmeny = []
for kod in morse_jelek:
    if kod != "":
        megfelelo_betu = "?"
        for betu_es_morse in kod_lista:
            if betu_es_morse[1] == kod:
                megfelelo_betu = betu_es_morse[0]
        eredmeny.append(megfelelo_betu)

with open("kimenet.txt", "a", encoding="utf-8") as output_file:
    output_file.write(f"Dekódolt szöveg: {''.join(eredmeny)}\n")

print("A szöveg átkódolva: ", " / ".join(morse_kod))
print()
print("Dekódolva:", "".join(eredmeny))
print()
print("A kimenet megtalálható a kimenet.txt fájlba!")
print()
input()
