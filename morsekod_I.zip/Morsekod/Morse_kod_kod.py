# Morse kód átalakító és visszafejtő program

# --- Fájl beolvasása memóriába ---
with open("morsekodok.txt", "r", encoding="utf-8") as f:
    kod_lista = [sor.strip().split() for sor in f if len(sor.strip().split()) == 2]

# --- SZÖVEG → MORSE KÓD ---

bill = input("Írj be egy szöveget: ").lower()  # felhasználói bemenet kisbetűsítve
morse_kod = []  # ebbe kerülnek a morse kód darabok

for karakter in bill:
    if karakter == " ":  # szóköz esetén dupla perrel jelöljük a szóközt
        morse_kod.append("/")  # külön szó elválasztása
        continue

    talalt = False
    for betu, morse in kod_lista:
        if betu.lower() == karakter:
            morse_kod.append(morse)
            talalt = True
            break

    if not talalt:
        morse_kod.append("?")  # ha nem található a karakter

# Kiírás
print("\nMorse kód: ", " / ".join(morse_kod))


# --- MORSE KÓD → SZÖVEG ---

morse_kod_bemenet = input("\nÍrj be egy morse kódot: ").strip()
# Például: .- / .-.. / -- / .- / / . / ... / / .- / .-.. / -- / .-

# Szétválasztjuk a kódokat ' / ' alapján (egy betű egy egység)
kodolva = morse_kod_bemenet.split(" / ")
szoveg = []

for kod in kodolva:
    if kod == "":
        continue
    elif kod == "/":
        szoveg.append(" ")  # dupla per = szóköz
        continue

    talalt = False
    for betu, morse in kod_lista:
        if morse == kod:
            szoveg.append(betu)
            talalt = True
            break

    if not talalt:
        szoveg.append("?")  # ha nincs ilyen morse kód

# Kiírás
print("Eredmény szöveg:", "".join(szoveg))
